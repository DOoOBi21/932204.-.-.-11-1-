﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

public class CalcController : Controller
{
    public IActionResult PassUsingModel()
    {
        var random = new Random();
        int num1 = random.Next(0, 11);
        int num2 = random.Next(0, 11);

        var model = new CalcModel
        {
            Num1 = num1,
            Num2 = num2
        };

        return View(model);
    }

    public IActionResult PassUsingViewData()
    {
        var random = new Random();
        int num1 = random.Next(0, 11);
        int num2 = random.Next(0, 11);

        ViewData["Num1"] = num1;
        ViewData["Num2"] = num2;
        ViewData["Add"] = num1 + num2;
        ViewData["Sub"] = num1 - num2;
        ViewData["Mul"] = num1 * num2;
        ViewData["Div"] = num2 != 0 ? num1 / num2 : null;
        ViewData["ErrorMessage"] = num2 == 0 ? "Division by zero error." : null;

        return View();
    }

    public IActionResult PassUsingViewBag()
    {
        var random = new Random();
        int num1 = random.Next(0, 11);
        int num2 = random.Next(0, 11);

        ViewBag.Num1 = num1;
        ViewBag.Num2 = num2;
        ViewBag.Add = num1 + num2;
        ViewBag.Sub = num1 - num2;
        ViewBag.Mul = num1 * num2;
        ViewBag.Div = num2 != 0 ? (double?)num1 / num2 : null;
        ViewBag.ErrorMessage = num2 == 0 ? "Division by zero error." : null;

        return View();
    }

    public IActionResult AccessServiceDirectly()
    {
        var random = new Random();
        int num1 = random.Next(0, 11);
        int num2 = random.Next(0, 11);

        var model = new CalcModel
        {
            Num1 = num1,
            Num2 = num2
        };

        return View(model);
    }
}
